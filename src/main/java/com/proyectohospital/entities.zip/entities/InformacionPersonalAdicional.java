package com.proyectohospital.entities;

import jakarta.persistence.*;

@Entity
@Table(name = "informacion_personal_adicional")
public class InformacionPersonalAdicional {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String idiomaAdicional;

    @Column(columnDefinition = "TEXT")
    private String actividadesComplementarias;

    @OneToOne
    @JoinColumn(name = "id_estudiante")
    private Estudiante estudiante;

    public InformacionPersonalAdicional() {
    }

    public Long getId() {
        return id;
    }

    public String getIdiomaAdicional() {
        return idiomaAdicional;
    }

    public void setIdiomaAdicional(String idiomaAdicional) {
        this.idiomaAdicional = idiomaAdicional;
    }

    public String getActividadesComplementarias() {
        return actividadesComplementarias;
    }

    public void setActividadesComplementarias(String actividadesComplementarias) {
        this.actividadesComplementarias = actividadesComplementarias;
    }

    public Estudiante getEstudiante() {
        return estudiante;
    }

    public void setEstudiante(Estudiante estudiante) {
        this.estudiante = estudiante;
    }
}