package com.proyectohospital.entities;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "datos_academicos")
public class DatosAcademicos {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDate fechaIngreso;

    private Integer semestre;

    @Column(precision = 4, scale = 2)
    private BigDecimal promedioAcumulado;

    @Column(columnDefinition = "TEXT")
    private String investigacion;

    @OneToOne
    @JoinColumn(name = "id_estudiante")
    private Estudiante estudiante;

    public DatosAcademicos() {
    }
}