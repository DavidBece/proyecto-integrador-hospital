@Entity
@Table(name = "programas")
public class Programa {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idPrograma;

    private String nombrePrograma;

    @ManyToOne
    @JoinColumn(name = "id_universidad")
    private Universidad universidad;

    @OneToMany(mappedBy = "programa")
    private List<Estudiante> estudiantes;
}