package com.proyectohospital.entities;

import jakarta.persistence.*;

@Entity
@Table(name = "salud")
public class Salud {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(columnDefinition = "TEXT")
    private String enfermedadesGenerales;

    @Column(columnDefinition = "TEXT")
    private String enfermedadesMentales;

    @Column(columnDefinition = "TEXT")
    private String medicamentos;

    @Column(columnDefinition = "TEXT")
    private String alergias;

    private Double peso;
    private Double talla;
    private Double imc;

    private String grupoSanguineo;

    @OneToOne
    @JoinColumn(name = "id_estudiante")
    private Estudiante estudiante;

    public Salud() {
    }
}