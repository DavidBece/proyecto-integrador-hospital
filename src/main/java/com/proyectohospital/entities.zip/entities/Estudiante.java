package com.proyectohospital.entities;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "estudiantes")
public class Estudiante {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_estudiante")
    private Long idEstudiante;

    // =====================================================
    // RELACION MUCHOS A UNO CON PROGRAMA
    // =====================================================
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_programa")
    private Programa programa;

    // =====================================================
    // DATOS PERSONALES
    // =====================================================
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id_datos_personales")
    private DatosPersonales datosPersonales;

    // =====================================================
    // CONTACTO
    // =====================================================
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id_contacto")
    private Contacto contacto;

    // =====================================================
    // REPRESENTANTE LEGAL
    // =====================================================
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id_representante")
    private RepresentanteLegal representanteLegal;

    // =====================================================
    // INFORMACION PERSONAL ADICIONAL
    // =====================================================
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id_info_personal")
    private InformacionPersonalAdicional informacionPersonalAdicional;

    // =====================================================
    // CONVIVENCIA
    // =====================================================
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id_convivencia")
    private Convivencia convivencia;

    // =====================================================
    // INFORMACION FAMILIAR
    // =====================================================
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id_info_familiar")
    private InformacionFamiliar informacionFamiliar;

    // =====================================================
    // SALUD
    // =====================================================
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id_salud")
    private Salud salud;

    // =====================================================
    // DATOS ACADEMICOS
    // =====================================================
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id_datos_academicos")
    private DatosAcademicos datosAcademicos;

    // =====================================================
    // RELACION CON PRACTICAS
    // =====================================================
    @OneToMany(mappedBy = "estudiante", cascade = CascadeType.ALL)
    private List<EstudiantePractica> practicas = new ArrayList<>();

    // =====================================================
    // RELACION CON REGISTROS DE INGRESO
    // =====================================================
    @OneToMany(mappedBy = "estudiante", cascade = CascadeType.ALL)
    private List<RegistroIngreso> registrosIngresos = new ArrayList<>();

    // =====================================================
    // CONSTRUCTOR VACIO
    // =====================================================
    public Estudiante() {
    }

    // =====================================================
    // GETTERS Y SETTERS
    // =====================================================

    public Long getIdEstudiante() {
        return idEstudiante;
    }

    public void setIdEstudiante(Long idEstudiante) {
        this.idEstudiante = idEstudiante;
    }

    public Programa getPrograma() {
        return programa;
    }

    public void setPrograma(Programa programa) {
        this.programa = programa;
    }

    public DatosPersonales getDatosPersonales() {
        return datosPersonales;
    }

    public void setDatosPersonales(DatosPersonales datosPersonales) {
        this.datosPersonales = datosPersonales;
    }

    public Contacto getContacto() {
        return contacto;
    }

    public void setContacto(Contacto contacto) {
        this.contacto = contacto;
    }

    public RepresentanteLegal getRepresentanteLegal() {
        return representanteLegal;
    }

    public void setRepresentanteLegal(RepresentanteLegal representanteLegal) {
        this.representanteLegal = representanteLegal;
    }

    public InformacionPersonalAdicional getInformacionPersonalAdicional() {
        return informacionPersonalAdicional;
    }

    public void setInformacionPersonalAdicional(InformacionPersonalAdicional informacionPersonalAdicional) {
        this.informacionPersonalAdicional = informacionPersonalAdicional;
    }

    public Convivencia getConvivencia() {
        return convivencia;
    }

    public void setConvivencia(Convivencia convivencia) {
        this.convivencia = convivencia;
    }

    public InformacionFamiliar getInformacionFamiliar() {
        return informacionFamiliar;
    }

    public void setInformacionFamiliar(InformacionFamiliar informacionFamiliar) {
        this.informacionFamiliar = informacionFamiliar;
    }

    public Salud getSalud() {
        return salud;
    }

    public void setSalud(Salud salud) {
        this.salud = salud;
    }

    public DatosAcademicos getDatosAcademicos() {
        return datosAcademicos;
    }

    public void setDatosAcademicos(DatosAcademicos datosAcademicos) {
        this.datosAcademicos = datosAcademicos;
    }

    public List<EstudiantePractica> getPracticas() {
        return practicas;
    }

    public void setPracticas(List<EstudiantePractica> practicas) {
        this.practicas = practicas;
    }

    public List<RegistroIngreso> getRegistrosIngresos() {
        return registrosIngresos;
    }

    public void setRegistrosIngresos(List<RegistroIngreso> registrosIngresos) {
        this.registrosIngresos = registrosIngresos;
    }
}