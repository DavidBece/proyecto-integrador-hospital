package com.proyectohospital.entities;

import jakarta.persistence.*;

@Entity
@Table(name = "informacion_familiar")
public class InformacionFamiliar {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nombrePadre;
    private Integer edadPadre;

    private String nombreMadre;
    private Integer edadMadre;

    private Boolean tieneHijos;

    @Column(columnDefinition = "TEXT")
    private String nombreHijos;

    @Column(columnDefinition = "TEXT")
    private String edadesHijos;

    private Boolean tieneConyuge;

    private String nombreConyuge;

    private Integer edadConyuge;

    @OneToOne
    @JoinColumn(name = "id_estudiante")
    private Estudiante estudiante;

    public InformacionFamiliar() {
    }

    public Long getId() {
        return id;
    }

    public String getNombrePadre() {
        return nombrePadre;
    }

    public void setNombrePadre(String nombrePadre) {
        this.nombrePadre = nombrePadre;
    }

    public Integer getEdadPadre() {
        return edadPadre;
    }

    public void setEdadPadre(Integer edadPadre) {
        this.edadPadre = edadPadre;
    }

    public String getNombreMadre() {
        return nombreMadre;
    }

    public void setNombreMadre(String nombreMadre) {
        this.nombreMadre = nombreMadre;
    }

    public Integer getEdadMadre() {
        return edadMadre;
    }

    public void setEdadMadre(Integer edadMadre) {
        this.edadMadre = edadMadre;
    }

    public Boolean getTieneHijos() {
        return tieneHijos;
    }

    public void setTieneHijos(Boolean tieneHijos) {
        this.tieneHijos = tieneHijos;
    }

    public String getNombreHijos() {
        return nombreHijos;
    }

    public void setNombreHijos(String nombreHijos) {
        this.nombreHijos = nombreHijos;
    }

    public String getEdadesHijos() {
        return edadesHijos;
    }

    public void setEdadesHijos(String edadesHijos) {
        this.edadesHijos = edadesHijos;
    }

    public Boolean getTieneConyuge() {
        return tieneConyuge;
    }

    public void setTieneConyuge(Boolean tieneConyuge) {
        this.tieneConyuge = tieneConyuge;
    }

    public String getNombreConyuge() {
        return nombreConyuge;
    }

    public void setNombreConyuge(String nombreConyuge) {
        this.nombreConyuge = nombreConyuge;
    }

    public Integer getEdadConyuge() {
        return edadConyuge;
    }

    public void setEdadConyuge(Integer edadConyuge) {
        this.edadConyuge = edadConyuge;
    }

    public Estudiante getEstudiante() {
        return estudiante;
    }

    public void setEstudiante(Estudiante estudiante) {
        this.estudiante = estudiante;
    }
}