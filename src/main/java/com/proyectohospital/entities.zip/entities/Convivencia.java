package com.proyectohospital.entities;

import jakarta.persistence.*;

@Entity
@Table(name = "convivencia")
public class Convivencia {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(columnDefinition = "TEXT")
    private String companerosVivienda;

    @Column(columnDefinition = "TEXT")
    private String nucleoFamiliar;

    @OneToOne
    @JoinColumn(name = "id_estudiante")
    private Estudiante estudiante;

    public Convivencia() {
    }

    public Long getId() {
        return id;
    }

    public String getCompanerosVivienda() {
        return companerosVivienda;
    }

    public void setCompanerosVivienda(String companerosVivienda) {
        this.companerosVivienda = companerosVivienda;
    }

    public String getNucleoFamiliar() {
        return nucleoFamiliar;
    }

    public void setNucleoFamiliar(String nucleoFamiliar) {
        this.nucleoFamiliar = nucleoFamiliar;
    }

    public Estudiante getEstudiante() {
        return estudiante;
    }

    public void setEstudiante(Estudiante estudiante) {
        this.estudiante = estudiante;
    }
}