package com.proyectohospital.entities;

import jakarta.persistence.*;

@Entity
@Table(name = "representante_legal")
public class RepresentanteLegal {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nombreRepresentante;
    private String parentescoRepresentante;
    private String celularRepresentante;
    private String direccionRepresentante;
    private String ciudadRepresentante;

    @OneToOne
    @JoinColumn(name = "id_estudiante")
    private Estudiante estudiante;

    public RepresentanteLegal() {
    }

    public Long getId() {
        return id;
    }

    public String getNombreRepresentante() {
        return nombreRepresentante;
    }

    public void setNombreRepresentante(String nombreRepresentante) {
        this.nombreRepresentante = nombreRepresentante;
    }

    public String getParentescoRepresentante() {
        return parentescoRepresentante;
    }

    public void setParentescoRepresentante(String parentescoRepresentante) {
        this.parentescoRepresentante = parentescoRepresentante;
    }

    public String getCelularRepresentante() {
        return celularRepresentante;
    }

    public void setCelularRepresentante(String celularRepresentante) {
        this.celularRepresentante = celularRepresentante;
    }

    public String getDireccionRepresentante() {
        return direccionRepresentante;
    }

    public void setDireccionRepresentante(String direccionRepresentante) {
        this.direccionRepresentante = direccionRepresentante;
    }

    public String getCiudadRepresentante() {
        return ciudadRepresentante;
    }

    public void setCiudadRepresentante(String ciudadRepresentante) {
        this.ciudadRepresentante = ciudadRepresentante;
    }

    public Estudiante getEstudiante() {
        return estudiante;
    }

    public void setEstudiante(Estudiante estudiante) {
        this.estudiante = estudiante;
    }
}