package com.proyectohospital.entities;

import jakarta.persistence.*;

@Entity
@Table(name = "contacto")
public class Contacto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String direccionTunja;
    private String residenciaPermanente;
    private String celular;
    private String correoElectronico;

    @OneToOne
    @JoinColumn(name = "id_estudiante")
    private Estudiante estudiante;

    public Contacto() {
    }

    public Long getId() {
        return id;
    }

    public String getDireccionTunja() {
        return direccionTunja;
    }

    public void setDireccionTunja(String direccionTunja) {
        this.direccionTunja = direccionTunja;
    }

    public String getResidenciaPermanente() {
        return residenciaPermanente;
    }

    public void setResidenciaPermanente(String residenciaPermanente) {
        this.residenciaPermanente = residenciaPermanente;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    public String getCorreoElectronico() {
        return correoElectronico;
    }

    public void setCorreoElectronico(String correoElectronico) {
        this.correoElectronico = correoElectronico;
    }

    public Estudiante getEstudiante() {
        return estudiante;
    }

    public void setEstudiante(Estudiante estudiante) {
        this.estudiante = estudiante;
    }
}